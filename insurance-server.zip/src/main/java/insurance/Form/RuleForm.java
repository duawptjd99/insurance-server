package insurance.Form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RuleForm {
    private int employeeIdx;
    private String content;
    private int clientIdx;
}
